#!/bin/bash

##ASSUMES the programs are compiled


#cd ../imp5Converter
#make clean; make -j opti;
#cd ../test
../imp5Converter/bin/imp5Converter --h reference.bcf --o reference.imp5 --r 20

#cd ../impute5
#make clean; make -j opti;
#cd ../test
../impute5/bin/impute5 --h reference.imp5 --g target.bcf --o imputed.bcf --r 20 --m ../maps/genetic_maps.b37/chr20.b37.gmap.gz

